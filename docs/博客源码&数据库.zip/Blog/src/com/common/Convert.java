package com.common;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Convert {
	
	/**
	 * 将结果转换成List<Map>格式
	 * **/
	public List<Map<String, Object>> convertList(PreparedStatement pst)
			throws SQLException {
		java.sql.ResultSetMetaData rsmd = pst.getMetaData();// 执行语句，得到结果集
		ResultSet rs = pst.executeQuery();
		int count = rs.getMetaData().getColumnCount();
		List<Map<String, Object>> mapList = new ArrayList<Map<String, Object>>();
		while (rs.next()) {
			Map m = new HashMap();
			for (int i = 1; i <= count; i++) {// 遍历�?
				m.put(rsmd.getColumnName(i).toString(), rs.getString(i));
			}
			mapList.add(m);
		}
		rs.close();
		return mapList;
	}
}
