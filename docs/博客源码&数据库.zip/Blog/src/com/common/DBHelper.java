package com.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DBHelper {
	 public static final String url = "jdbc:mysql://127.0.0.1:3306/blog?useUnicode=true&amp;characterEncoding=utf-8";  
	    public static final String name = "com.mysql.jdbc.Driver";  
	    public static final String user = "root";  
	    public static final String password = "123456";  
	  
	    public Connection conn = null;  
	    public PreparedStatement pst = null;  
	  
	    /**
	     * 杩炴帴鏁版嵁锟�
	     * */
	    public DBHelper(String sql) {  
	        try {  
	            Class.forName(name);//鎸囧畾杩炴帴绫诲瀷  
	            conn = DriverManager.getConnection(url, user, password);//鑾峰彇杩炴帴  
	            pst = conn.prepareStatement(sql);//鍑嗗鎵ц璇彞     
	        } catch (Exception e) {  
	            e.printStackTrace();  
	        }  
	    }  
	  
	    /**
	     * 鏂紑鏁版嵁搴撻摼锟�
	     * */
	    public void close() {  
	        try {  
	            this.conn.close();  
	            this.pst.close();  
	        } catch (SQLException e) {  
	            e.printStackTrace();  
	        }  
	    }  
}
