package com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.UserService;

public class UserLoginController extends HttpServlet {
	 @Override  
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)  
	            throws ServletException, IOException {   
	    	 
		 
		String username=  req.getParameter("username");
		String password=  req.getParameter("password");
	 
	 
			UserService service = new UserService();
			List<Map<String, Object>> uList =service.queryByIdPsw(username, password);
			// ��½
			if(null!=uList&&uList.size()>0){
				req.setAttribute("leftPage", "/userLeft.html");  
				req.setAttribute("rightPage", "logView.jsp");
				req.getRequestDispatcher("/main.jsp").forward(req, resp);
			}
			//��½ʧ��
			else{ 
				req.setAttribute("errorMsg", "��½ʧ��");
				req.getRequestDispatcher("/userLoginForm.jsp").forward(req, resp);
			}
	 
	  }
	  
}
