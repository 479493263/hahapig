package com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.UserService;

public class ShowAllUsersController extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		UserService service = new UserService();
		List<Map<String, Object>> allList = service.queryAll();

		req.setAttribute("allList", allList);
		req.getRequestDispatcher("/userList.jsp").forward(req, resp);

	}

}
