package com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.common.StringUtil;
import com.dao.User;
import com.service.UserService;

public class UserRegisterController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		String username = req.getParameter("username");
		String tel = req.getParameter("tel");
		String password = req.getParameter("password");

		User u = new User();
		u.setId(StringUtil.getRandomString(11));
		u.setTel(tel);
		u.setPassword(password);
		u.setUsername(username);
		UserService service = new UserService();
		int i = service.insert(u);
		 
		if (i > 0) { 
			req.getRequestDispatcher("/userLoginForm.jsp").forward(req, resp);
		} 
		else { 
			req.getRequestDispatcher("/errorPage.jsp").forward(req, resp);
		}

	}
}
