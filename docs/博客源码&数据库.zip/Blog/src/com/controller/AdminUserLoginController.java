package com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.AdminUserService;

public class AdminUserLoginController extends HttpServlet {
	 @Override  
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)  
	            throws ServletException, IOException {   
	    	 
		 
		String adminname=  req.getParameter("adminname");
		String password=  req.getParameter("password");
	 
	 
			AdminUserService service = new AdminUserService();
			List<Map<String, Object>> uList =service.queryByIdPsw(adminname, password);
			// ��½
			if(null!=uList&&uList.size()>0){
				req.setAttribute("leftPage", "/adminLeft.html");  
				req.setAttribute("rightPage", "logView.jsp");
				req.getRequestDispatcher("/main.jsp").forward(req, resp);
			}
			//��½ʧ��
			else{ 
				req.setAttribute("errorMsg", "��½ʧ��");
				req.getRequestDispatcher("/adminLoginForm.jsp").forward(req, resp);
			}
	 
	  }
	  
}
