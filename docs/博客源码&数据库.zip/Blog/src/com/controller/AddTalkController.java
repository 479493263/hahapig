package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.common.StringUtil;
import com.dao.Talk;
import com.service.TalkService;

public class AddTalkController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String blogId=  req.getParameter("blogId");
		String content=  req.getParameter("content");
		
		Talk b = new Talk();
		b.setId(StringUtil.getRandomString(10));
		b.setContent(content);
		b.setBlogId(blogId);
	 
		TalkService service = new TalkService();
		int i = service.insert(b);

		 if(i>0){
			 req.getRequestDispatcher("/successPage.jsp").forward(req, resp);
		 }
		

	}

}
