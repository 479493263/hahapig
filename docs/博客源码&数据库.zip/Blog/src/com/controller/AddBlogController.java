package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.common.StringUtil;
import com.dao.Blog;
import com.service.BlogService;

public class AddBlogController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String content=  req.getParameter("content");
		String title=  req.getParameter("title");
		
		Blog b = new Blog();
		b.setId(StringUtil.getRandomString(10));
		b.setContent(content);
		b.setTitle(title);
		BlogService service = new BlogService();
		int i = service.insert(b);

		 if(i>0){
			 req.getRequestDispatcher("/successPage.jsp").forward(req, resp);
		 }
		

	}

}
