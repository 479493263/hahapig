package com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.BlogService;

public class ShowAllBlogController extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		BlogService service = new BlogService();
		List<Map<String, Object>> allList = service.queryAll();

		req.setAttribute("allList", allList);
		req.getRequestDispatcher("/blogList.jsp").forward(req, resp);

	}

}
