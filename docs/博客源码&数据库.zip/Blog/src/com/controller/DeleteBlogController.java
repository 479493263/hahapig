package com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.BlogService;
import com.service.UserService;

public class DeleteBlogController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		String id = req.getParameter("id");

		BlogService service = new BlogService();
		int i = service.delete(id);

		if (i > 0) {
		 
			req.getRequestDispatcher("/successPage.jsp").forward(req, resp);
		}

	}

}
