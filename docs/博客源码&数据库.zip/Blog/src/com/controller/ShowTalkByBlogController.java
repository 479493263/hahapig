package com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.service.TalkService;

public class ShowTalkByBlogController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String blogId=  req.getParameter("blogId");
		TalkService service = new TalkService();
		List<Map<String, Object>> allList = service.queryByBlogId(blogId);

		req.setAttribute("allList", allList);
		req.getRequestDispatcher("/talkList.jsp").forward(req, resp);

	}

}
