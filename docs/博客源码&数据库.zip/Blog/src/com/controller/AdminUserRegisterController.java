package com.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.common.StringUtil;
import com.dao.AdminUser;
import com.service.AdminUserService;

public class AdminUserRegisterController extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		String adminname = req.getParameter("adminname");
		String tel = req.getParameter("tel");
		String password = req.getParameter("password");

		AdminUser u = new AdminUser();
		u.setId(StringUtil.getRandomString(11));
		u.setTel(tel);
		u.setPassword(password);
		u.setAdminname(adminname);
		AdminUserService service = new AdminUserService();
		int i = service.insert(u);
		 
		if (i > 0) { 
			req.getRequestDispatcher("/adminLoginForm.jsp").forward(req, resp);
		} 
		else { 
			req.getRequestDispatcher("/errorPage.jsp").forward(req, resp);
		}

	}
}
