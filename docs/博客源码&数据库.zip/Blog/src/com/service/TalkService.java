package com.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.common.Convert;
import com.common.DBHelper;
import com.dao.Talk;

public class TalkService {
	  static DBHelper db = null;  
	    Convert c = new Convert ();
	  
	    //查询所有
	    public List<Map<String,Object>> queryAll() {  
	    	String  sql = "select * from talk ";//查询所有SQL
	        db = new DBHelper(sql);// 连接数据库
	   	 List<Map<String,Object>> allList =null;
	       
	             try {   
	             	 allList =	 c.convertList(db.pst); 
	                 db.close();//关闭连接
	             } catch (SQLException e) {  
	                 e.printStackTrace();  
	             } 
	        
			return allList;  
	    }  
	    
	    //插入信息
	    public int insert(Talk u) { 
	        String sql = "insert into talk (id,blog_id,content) values(?,?,?)";
	        db = new DBHelper(sql);// 连接数据库 
	        int i=0;
	        try {
	        	db.pst.setObject(1, u.getId());
	        	db.pst.setObject(2, u.getBlogId()); 
	            db.pst.setObject(3, u.getContent()); 
	            
	            i= db.pst.executeUpdate(); 
	            db.close();//关闭连接
	           
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } 
	        return i;
	    }
	    
	    public int delete(String id) { 
	        String sql = "delete from talk where id='" + id + "'";
	        db = new DBHelper(sql);
	        int i=0;
	        try { 
	        	i= db.pst.executeUpdate(); 
	             db.close();//�ر�����   
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } 
	        return i;
	    }
	    
	  
	    
	    public List<Map<String,Object>> queryByBlogId(String blogId) {  
	    	String  sql = "select * from talk where blog_id= '"+blogId+"'";//查询所有SQL
	        db = new DBHelper(sql);// 连接数据库
	   	 List<Map<String,Object>> allList =null;
	       
	             try {   
	             	 allList =	 c.convertList(db.pst); 
	                 db.close();//关闭连接
	             } catch (SQLException e) {  
	                 e.printStackTrace();  
	             } 
	        
			return allList;  
	    }  
	    
	    
	    
}
