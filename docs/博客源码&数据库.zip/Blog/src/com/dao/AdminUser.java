package com.dao;

public class AdminUser {
public String id;
public String adminname;
public String password;
public String tel;
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getAdminname() {
	return adminname;
}
public void setAdminname(String adminname) {
	this.adminname = adminname;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getTel() {
	return tel;
}
public void setTel(String tel) {
	this.tel = tel;
}



}
